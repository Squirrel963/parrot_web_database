import turtle
p = turtle.Pen()
p.forward(100)

turtle.done()